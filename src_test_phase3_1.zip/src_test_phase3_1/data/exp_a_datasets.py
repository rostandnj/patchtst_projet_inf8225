"""
src/data/exp_a_datasets.py

Datasets PyTorch pour Exp A : classification TDAH/CTRL à partir des
séquences inter-traits de paramètres sigma-lognormaux.

DEUX FORMATS :

    SequenceChildDataset (Exp A.1, A.3 — séquence complète)
        - Un échantillon = un enfant
        - Input  : (M=14, L=L_target) après padding/truncation
        - Label  : 0/1
        - Padding mask retourné si activé (pour masquer les positions
          ajoutées des enfants à <L_target traits)

    SlidingWindowDataset (Exp A.2, A.4 — fenêtres glissantes)
        - Un échantillon = une fenêtre de L_window traits consécutifs
          d'un enfant
        - Input  : (M=14, L_window) sans padding (toutes les fenêtres
          ont la même longueur)
        - Label  : hérité de l'enfant
        - Métadonnées : child_id de la fenêtre (pour agrégation à
          l'inférence)

NORMALISATION :

    On NE NORMALISE PAS dans le Dataset (RevIN s'en charge à l'intérieur
    du modèle PatchTST). Les paramètres sigma-lognormaux sont fournis
    bruts dans leurs unités natives (mm, s, dB, etc.).

CONFIGURATION :

    Tous les datasets prennent en entrée un sous-ensemble d'enfants (par
    leurs IDs) du ProcessedDataset. C'est ce qui permet de les utiliser
    directement dans la boucle LOSO :

        train_ds = SequenceChildDataset(processed_dataset, train_child_ids,
                                        seq_len=20)
        test_ds  = SequenceChildDataset(processed_dataset, [test_child_id],
                                        seq_len=20)
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
from torch.utils.data import Dataset

from src.utils.data_io import ProcessedDataset


# Pour Exp A on travaille sur 14 paramètres
DEFAULT_N_PARAMS = 14


# ---------------------------------------------------------------------------
# Sequence-level dataset (Exp A.1, A.3)
# ---------------------------------------------------------------------------


@dataclass
class SequenceItem:
    """Un échantillon retourné par SequenceChildDataset (utile pour debug)."""
    x: torch.Tensor                # (M, L_target)
    y: int                         # label 0/1
    child_id: str
    n_strokes_actual: int          # nombre de traits réels (avant padding)
    pad_mask: torch.Tensor         # (L_target,) bool, True = position paddée


class SequenceChildDataset(Dataset):
    """Un échantillon = un enfant entier (séquence ordonnée de ses traits).

    Args:
        dataset : ProcessedDataset chargé.
        child_ids : sous-ensemble d'enfants à utiliser.
        seq_len : longueur cible L de la séquence (ex: 20).
        truncation : 'first' (garde les seq_len premiers traits) ou
            'last' (garde les seq_len derniers).
        pad_strategy : 'zero' (zero-pad), 'edge' (réplique le dernier
            trait) ou 'mean' (réplique la moyenne par canal). 'zero' est
            recommandé avec un masque d'attention.
        return_dict : si True, retourne un dict avec toutes les métadonnées
            (utile en debug). Si False (défaut), retourne (x, y) compatible
            DataLoader standard.
    """

    def __init__(
        self,
        dataset: ProcessedDataset,
        child_ids: list[str],
        seq_len: int = 20,
        truncation: str = "first",
        pad_strategy: str = "zero",
        return_dict: bool = False,
    ):
        if truncation not in ("first", "last"):
            raise ValueError(f"truncation must be 'first' or 'last', got {truncation!r}")
        if pad_strategy not in ("zero", "edge", "mean"):
            raise ValueError(f"pad_strategy must be 'zero', 'edge' or 'mean'")

        self.dataset = dataset
        self.child_ids = list(child_ids)
        self.seq_len = seq_len
        self.truncation = truncation
        self.pad_strategy = pad_strategy
        self.return_dict = return_dict

        # Pre-compute les tenseurs (rapide, n=24 enfants)
        self._items: list[SequenceItem] = [
            self._build_item(cid) for cid in self.child_ids
        ]

    @property
    def n_channels(self) -> int:
        return self.dataset.params_per_child[self.child_ids[0]].shape[1]

    def _build_item(self, cid: str) -> SequenceItem:
        params = self.dataset.params_per_child[cid]   # (n_strokes, M)
        n_actual = params.shape[0]
        M = params.shape[1]

        # Truncation si trop long
        if n_actual >= self.seq_len:
            if self.truncation == "first":
                params = params[: self.seq_len]
            else:
                params = params[-self.seq_len :]
            n_kept = self.seq_len
            pad_mask = np.zeros(self.seq_len, dtype=bool)
        else:
            # Padding nécessaire
            n_pad = self.seq_len - n_actual
            if self.pad_strategy == "zero":
                pad_block = np.zeros((n_pad, M), dtype=params.dtype)
            elif self.pad_strategy == "edge":
                pad_block = np.tile(params[-1:], (n_pad, 1))
            else:  # mean
                pad_block = np.tile(params.mean(axis=0, keepdims=True), (n_pad, 1))
            params = np.concatenate([params, pad_block], axis=0)
            n_kept = n_actual
            pad_mask = np.zeros(self.seq_len, dtype=bool)
            pad_mask[n_actual:] = True

        # (L, M) -> (M, L) pour PatchTST (channel-first)
        x = torch.from_numpy(params.T).float()         # (M, L)
        y = self.dataset.labels_per_child[cid]
        pad_mask_t = torch.from_numpy(pad_mask)
        return SequenceItem(
            x=x, y=int(y), child_id=cid, n_strokes_actual=n_kept, pad_mask=pad_mask_t,
        )

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, idx: int):
        item = self._items[idx]
        if self.return_dict:
            return {
                "x": item.x,
                "y": torch.tensor(item.y, dtype=torch.long),
                "child_id": item.child_id,
                "pad_mask": item.pad_mask,
                "n_strokes_actual": item.n_strokes_actual,
            }
        return item.x, torch.tensor(item.y, dtype=torch.long)


# ---------------------------------------------------------------------------
# Sliding window dataset (Exp A.2, A.4)
# ---------------------------------------------------------------------------


@dataclass
class WindowItem:
    """Un échantillon de SlidingWindowDataset."""
    x: torch.Tensor                # (M, L_window)
    y: int                         # label de l'enfant
    child_id: str
    window_start: int              # index dans la séquence de l'enfant
    window_end: int                # exclu


class SlidingWindowDataset(Dataset):
    """Un échantillon = une fenêtre de L_window traits consécutifs d'un enfant.

    Génère toutes les fenêtres possibles de taille L_window avec stride
    `stride` à partir des séquences de chaque enfant.

    Pour un enfant avec n_strokes traits :
        n_windows = max(0, (n_strokes - L_window) // stride + 1)

    Si un enfant a moins que L_window traits, il ne contribue à aucune fenêtre.
    On émet un warning dans ce cas (ne devrait pas arriver après préprocessing
    si L_window <= min strokes_per_child).

    Pour l'inférence au niveau enfant : voir aggregate_window_predictions().
    """

    def __init__(
        self,
        dataset: ProcessedDataset,
        child_ids: list[str],
        window_len: int = 10,
        stride: int = 1,
        return_dict: bool = False,
    ):
        if window_len <= 0 or stride <= 0:
            raise ValueError("window_len and stride must be positive")

        self.dataset = dataset
        self.child_ids = list(child_ids)
        self.window_len = window_len
        self.stride = stride
        self.return_dict = return_dict

        self._items: list[WindowItem] = []
        self._skipped_children: list[str] = []
        for cid in self.child_ids:
            self._items.extend(self._windows_for_child(cid))

    @property
    def n_channels(self) -> int:
        return self.dataset.params_per_child[self.child_ids[0]].shape[1]

    def _windows_for_child(self, cid: str) -> list[WindowItem]:
        params = self.dataset.params_per_child[cid]   # (n_strokes, M)
        n_strokes = params.shape[0]
        if n_strokes < self.window_len:
            self._skipped_children.append(cid)
            return []
        items = []
        y = self.dataset.labels_per_child[cid]
        for start in range(0, n_strokes - self.window_len + 1, self.stride):
            end = start + self.window_len
            window = params[start:end]                 # (L_window, M)
            x = torch.from_numpy(window.T).float()     # (M, L_window)
            items.append(WindowItem(
                x=x, y=int(y), child_id=cid,
                window_start=start, window_end=end,
            ))
        return items

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, idx: int):
        item = self._items[idx]
        if self.return_dict:
            return {
                "x": item.x,
                "y": torch.tensor(item.y, dtype=torch.long),
                "child_id": item.child_id,
                "window_start": item.window_start,
                "window_end": item.window_end,
            }
        return item.x, torch.tensor(item.y, dtype=torch.long)

    def child_id_per_item(self) -> list[str]:
        """Liste des child_id alignée sur self._items, pour l'agrégation."""
        return [it.child_id for it in self._items]


# ---------------------------------------------------------------------------
# Aggregation des prédictions niveau fenêtre -> niveau enfant
# ---------------------------------------------------------------------------


def aggregate_window_predictions(
    child_ids_per_window: list[str],
    proba_per_window: np.ndarray,
    aggregation: str = "mean_proba",
) -> tuple[np.ndarray, np.ndarray]:
    """Agrège les prédictions de fenêtres en prédictions par enfant.

    Args:
        child_ids_per_window : (n_windows,) IDs enfant.
        proba_per_window : (n_windows,) P(ADHD=1) prédite.
        aggregation : 'mean_proba' ou 'majority_vote'.

    Returns:
        (unique_child_ids, proba_per_child)
    """
    child_ids = np.asarray(child_ids_per_window)
    proba = np.asarray(proba_per_window)
    unique_ids = np.array(sorted(set(child_ids.tolist())))
    proba_per_child = np.zeros(len(unique_ids))
    for i, cid in enumerate(unique_ids):
        mask = child_ids == cid
        if aggregation == "mean_proba":
            proba_per_child[i] = float(np.mean(proba[mask]))
        elif aggregation == "majority_vote":
            preds = (proba[mask] >= 0.5).astype(int)
            n1 = int(preds.sum())
            n0 = len(preds) - n1
            if n1 > n0:
                proba_per_child[i] = 1.0
            elif n0 > n1:
                proba_per_child[i] = 0.0
            else:
                proba_per_child[i] = float(np.mean(proba[mask]))
        else:
            raise ValueError(f"Unknown aggregation: {aggregation}")
    return unique_ids, proba_per_child
